import React from 'react';
import { TouchableOpacity } from 'react-native';
import { createDrawerNavigator, DrawerActions } from '@react-navigation/drawer';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import Sidebar from '../components/Sidebar';
import HeaderLeft from '../components/HeaderLeft';
import { DoctorDataProvider } from '../context/DoctorDataContext';
import DoctorOverviewScreen from '../screens/doctor/DoctorOverviewScreen';
import DoctorPatientsListScreen from '../screens/doctor/DoctorPatientsListScreen';
import DoctorPatientDetailScreen from '../screens/doctor/DoctorPatientDetailScreen';
import DoctorAssignedScreen from '../screens/doctor/DoctorAssignedScreen';
import DoctorConsultationScreen from '../screens/doctor/DoctorConsultationScreen';
import { C } from '../theme';

const Drawer = createDrawerNavigator();
const PatientsStack = createNativeStackNavigator();
const ICONS = { Overview: 'home', 'Patient Records': 'users', 'Assigned to Me': 'activity', Consultation: 'file-plus' };
const SECTIONS = [
  { title: 'Main', routes: ['Overview'] },
  { title: 'Clinical', routes: ['Patient Records', 'Assigned to Me', 'Consultation'] },
];

// The "Patients" drawer screen hides the drawer's own header (it needs its
// own stack header for the List -> Detail push), so the entry screen needs
// its own hamburger button — the toggleDrawer action bubbles up to the
// parent Drawer navigator automatically.
function MenuButton() {
  const navigation = useNavigation();
  return (
    <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.toggleDrawer())} style={{ marginLeft: 12, padding: 4 }}>
      <Feather name="menu" size={22} color="#fff" />
    </TouchableOpacity>
  );
}

function PatientsStackNav() {
  return (
    <PatientsStack.Navigator screenOptions={{ headerStyle: { backgroundColor: C.navyMid }, headerTintColor: '#fff', headerTitleStyle: { fontWeight: '700' } }}>
      <PatientsStack.Screen name="PatientsList" component={DoctorPatientsListScreen} options={{ title: 'Patient Records', headerLeft: () => <MenuButton /> }} />
      <PatientsStack.Screen name="PatientDetail" component={DoctorPatientDetailScreen} options={{ title: 'Patient Detail' }} />
    </PatientsStack.Navigator>
  );
}

export default function DoctorTabs() {
  return (
    <DoctorDataProvider>
      <Drawer.Navigator
        drawerContent={(props) => <Sidebar {...props} portalName="Physician Portal" icons={ICONS} accent={C.blue} sections={SECTIONS} />}
        screenOptions={{
          headerStyle: { backgroundColor: C.navyMid },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: '700' },
          drawerStyle: { width: 260 },
          headerLeft: () => <HeaderLeft />,
        }}
      >
        <Drawer.Screen name="Overview" component={DoctorOverviewScreen} options={{ title: 'Physician Portal' }} />
        <Drawer.Screen name="Patient Records" component={PatientsStackNav} options={{ headerShown: false }} />
        <Drawer.Screen name="Assigned to Me" component={DoctorAssignedScreen} options={{ title: 'Assigned to Me' }} />
        <Drawer.Screen name="Consultation" component={DoctorConsultationScreen} options={{ title: 'Consultation' }} />
      </Drawer.Navigator>
    </DoctorDataProvider>
  );
}
