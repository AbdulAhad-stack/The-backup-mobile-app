import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Sidebar from '../components/Sidebar';
import HeaderLeft from '../components/HeaderLeft';
import { AdminDataProvider } from '../context/AdminDataContext';
import AdminOverviewScreen from '../screens/admin/AdminOverviewScreen';
import { AdminStaffScreen, AdminDoctorsScreen } from '../screens/admin/AdminPeopleScreen';
import { AdminDoctorAvailabilityScreen, AdminAttendanceScreen, AdminPayrollScreen } from '../screens/admin/AdminHRScreen';
import { AdminFeesScreen, AdminCashScreen, AdminLabCatalogScreen } from '../screens/admin/AdminFinanceScreen';
import { AdminWastageScreen, AdminMismatchesScreen, AdminReportsScreen, AdminAuditScreen } from '../screens/admin/AdminMoreScreen';
import { C } from '../theme';

const Drawer = createDrawerNavigator();

// Flat, web-matching structure: same 13 sections, same grouping, same order
// as the web sidebar — instead of 5 tabs with segments hidden inside.
const ICONS = {
  Overview: 'home', Staff: 'users', Doctors: 'user-check', 'Doctor Availability': 'calendar',
  Attendance: 'calendar', Payroll: 'briefcase',
  Fees: 'credit-card', 'Cash Reconciliation': 'clipboard', 'Lab Test Catalog': 'activity',
  'Wastage Approvals': 'alert-triangle', 'Rx Mismatches': 'x-circle',
  'Financial Reports': 'trending-up', 'Audit Log': 'clock',
};

const SECTIONS = [
  { title: 'Main', routes: ['Overview'] },
  { title: 'Management', routes: ['Staff', 'Doctors', 'Doctor Availability'] },
  { title: 'HR & Payroll', routes: ['Attendance', 'Payroll'] },
  { title: 'Billing', routes: ['Fees', 'Cash Reconciliation', 'Lab Test Catalog'] },
  { title: 'Pharmacy Oversight', routes: ['Wastage Approvals', 'Rx Mismatches'] },
  { title: 'Reports', routes: ['Financial Reports'] },
  { title: 'Security', routes: ['Audit Log'] },
];

export default function AdminTabs() {
  return (
    <AdminDataProvider>
      <Drawer.Navigator
        drawerContent={(props) => <Sidebar {...props} portalName="Admin Portal" icons={ICONS} accent={C.blue} sections={SECTIONS} />}
        screenOptions={{
          headerStyle: { backgroundColor: C.navyMid },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: '700' },
          drawerStyle: { width: 260 },
          headerLeft: () => <HeaderLeft />,
        }}
      >
        <Drawer.Screen name="Overview" component={AdminOverviewScreen} options={{ title: 'Admin Portal' }} />
        <Drawer.Screen name="Staff" component={AdminStaffScreen} />
        <Drawer.Screen name="Doctors" component={AdminDoctorsScreen} />
        <Drawer.Screen name="Doctor Availability" component={AdminDoctorAvailabilityScreen} />
        <Drawer.Screen name="Attendance" component={AdminAttendanceScreen} />
        <Drawer.Screen name="Payroll" component={AdminPayrollScreen} />
        <Drawer.Screen name="Fees" component={AdminFeesScreen} />
        <Drawer.Screen name="Cash Reconciliation" component={AdminCashScreen} />
        <Drawer.Screen name="Lab Test Catalog" component={AdminLabCatalogScreen} />
        <Drawer.Screen name="Wastage Approvals" component={AdminWastageScreen} />
        <Drawer.Screen name="Rx Mismatches" component={AdminMismatchesScreen} />
        <Drawer.Screen name="Financial Reports" component={AdminReportsScreen} />
        <Drawer.Screen name="Audit Log" component={AdminAuditScreen} />
      </Drawer.Navigator>
    </AdminDataProvider>
  );
}
