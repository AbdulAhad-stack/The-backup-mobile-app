import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Sidebar from '../components/Sidebar';
import HeaderLeft from '../components/HeaderLeft';
import { LabDataProvider } from '../context/LabDataContext';
import LabOverviewScreen from '../screens/lab/LabOverviewScreen';
import LabSamplesScreen from '../screens/lab/LabSamplesScreen';
import LabReportsScreen from '../screens/lab/LabReportsScreen';

const Drawer = createDrawerNavigator();
const ICONS = { Overview: 'home', Samples: 'activity', Reports: 'file-text' };
const SECTIONS = [
  { title: 'Main', routes: ['Overview'] },
  { title: 'Work', routes: ['Samples', 'Reports'] },
];
const GREEN = '#059669';

export default function LabTabs() {
  return (
    <LabDataProvider>
      <Drawer.Navigator
        drawerContent={(props) => <Sidebar {...props} portalName="Lab Portal" icons={ICONS} accent={GREEN} sections={SECTIONS} />}
        screenOptions={{
          headerStyle: { backgroundColor: '#065f46' },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: '700' },
          drawerStyle: { width: 260 },
          headerLeft: () => <HeaderLeft />,
        }}
      >
        <Drawer.Screen name="Overview" component={LabOverviewScreen} options={{ title: 'Lab Portal' }} />
        <Drawer.Screen name="Samples" component={LabSamplesScreen} options={{ title: 'Samples' }} />
        <Drawer.Screen name="Reports" component={LabReportsScreen} options={{ title: 'Reports' }} />
      </Drawer.Navigator>
    </LabDataProvider>
  );
}
