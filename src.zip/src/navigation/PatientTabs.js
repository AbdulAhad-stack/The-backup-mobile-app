import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Sidebar from '../components/Sidebar';
import HeaderLeft from '../components/HeaderLeft';
import { PatientDataProvider } from '../context/PatientDataContext';
import OverviewScreen from '../screens/patient/OverviewScreen';
import MedicationsScreen from '../screens/patient/MedicationsScreen';
import HistoryScreen from '../screens/patient/HistoryScreen';
import RemindersScreen from '../screens/patient/RemindersScreen';
import BookingScreen from '../screens/patient/BookingScreen';
import { C } from '../theme';

const Drawer = createDrawerNavigator();

const ICONS = {
  Overview: 'home',
  Medications: 'package',
  'Medical History': 'clipboard',
  'Daily Schedule': 'bell',
  'Book Appointment': 'calendar',
};
const SECTIONS = [
  { title: 'My Health', routes: ['Overview', 'Medications', 'Medical History'] },
  { title: 'Reminders', routes: ['Daily Schedule'] },
  { title: 'Appointments', routes: ['Book Appointment'] },
];

export default function PatientTabs() {
  return (
    <PatientDataProvider>
      <Drawer.Navigator
        drawerContent={(props) => <Sidebar {...props} portalName="Patient Portal" icons={ICONS} accent={C.blue} sections={SECTIONS} />}
        screenOptions={{
          headerStyle: { backgroundColor: C.navyMid },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: '700' },
          drawerStyle: { width: 260 },
          headerLeft: () => <HeaderLeft />,
        }}
      >
        <Drawer.Screen name="Overview" component={OverviewScreen} options={{ title: 'MediCare' }} />
        <Drawer.Screen name="Medications" component={MedicationsScreen} options={{ title: 'Medications' }} />
        <Drawer.Screen name="Medical History" component={HistoryScreen} options={{ title: 'Medical History' }} />
        <Drawer.Screen name="Daily Schedule" component={RemindersScreen} options={{ title: 'Daily Schedule' }} />
        <Drawer.Screen name="Book Appointment" component={BookingScreen} options={{ title: 'Book Appointment' }} />
      </Drawer.Navigator>
    </PatientDataProvider>
  );
}
