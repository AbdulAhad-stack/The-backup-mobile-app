import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Sidebar from '../components/Sidebar';
import HeaderLeft from '../components/HeaderLeft';
import { ReceptionDataProvider } from '../context/ReceptionDataContext';
import ReceptionOverviewScreen from '../screens/reception/ReceptionOverviewScreen';
import ReceptionRegisterPatientScreen, { ReceptionAllRecordsScreen } from '../screens/reception/ReceptionPatientsScreen';
import ReceptionAppointmentsScreen from '../screens/reception/ReceptionAppointmentsScreen';
import ReceptionCollectFeeScreen, { ReceptionDayCloseScreen, ReceptionLabOrdersScreen } from '../screens/reception/ReceptionBillingScreen';
import ReceptionAssignDoctorScreen, { ReceptionAttendanceScreen } from '../screens/reception/ReceptionMoreScreen';
import { C } from '../theme';

const Drawer = createDrawerNavigator();

// Flat, web-matching structure: same 9 sections, same grouping, same order
// as the web sidebar — instead of 5 tabs with segments hidden inside.
const ICONS = {
  Overview: 'home', 'Register Patient': 'user-plus', 'Assign Doctor': 'link', Appointments: 'calendar',
  'All Records': 'list', 'Collect Fee': 'credit-card', 'Day Close': 'check-circle',
  'Lab Orders': 'activity', Attendance: 'check-circle',
};

const SECTIONS = [
  { title: 'Main', routes: ['Overview'] },
  { title: 'Registration', routes: ['Register Patient'] },
  { title: 'Assignment', routes: ['Assign Doctor', 'Appointments'] },
  { title: 'Records', routes: ['All Records'] },
  { title: 'Billing', routes: ['Collect Fee', 'Day Close'] },
  { title: 'Lab', routes: ['Lab Orders'] },
  { title: 'Staff', routes: ['Attendance'] },
];

export default function ReceptionTabs() {
  return (
    <ReceptionDataProvider>
      <Drawer.Navigator
        drawerContent={(props) => <Sidebar {...props} portalName="Receptionist Portal" icons={ICONS} accent={C.blue} sections={SECTIONS} />}
        screenOptions={{
          headerStyle: { backgroundColor: C.navyMid },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: '700' },
          drawerStyle: { width: 260 },
          headerLeft: () => <HeaderLeft />,
        }}
      >
        <Drawer.Screen name="Overview" component={ReceptionOverviewScreen} options={{ title: 'Receptionist Portal' }} />
        <Drawer.Screen name="Register Patient" component={ReceptionRegisterPatientScreen} />
        <Drawer.Screen name="Assign Doctor" component={ReceptionAssignDoctorScreen} />
        <Drawer.Screen name="Appointments" component={ReceptionAppointmentsScreen} />
        <Drawer.Screen name="All Records" component={ReceptionAllRecordsScreen} />
        <Drawer.Screen name="Collect Fee" component={ReceptionCollectFeeScreen} />
        <Drawer.Screen name="Day Close" component={ReceptionDayCloseScreen} />
        <Drawer.Screen name="Lab Orders" component={ReceptionLabOrdersScreen} />
        <Drawer.Screen name="Attendance" component={ReceptionAttendanceScreen} />
      </Drawer.Navigator>
    </ReceptionDataProvider>
  );
}
