import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Sidebar from '../components/Sidebar';
import HeaderLeft from '../components/HeaderLeft';
import { PharmacyDataProvider } from '../context/PharmacyDataContext';
import PharmacyOverviewScreen from '../screens/pharmacy/PharmacyOverviewScreen';
import MedicinesScreen from '../screens/pharmacy/MedicinesScreen';
import SuppliersScreen from '../screens/pharmacy/SuppliersScreen';
import AlertsScreen from '../screens/pharmacy/AlertsScreen';
import DispenseScreen from '../screens/pharmacy/DispenseScreen';

const Drawer = createDrawerNavigator();
const ICONS = { Overview: 'home', Medicines: 'package', Suppliers: 'briefcase', Alerts: 'alert-triangle', 'Dispense (Rx)': 'clipboard' };
const SECTIONS = [
  { title: 'Main', routes: ['Overview'] },
  { title: 'Inventory', routes: ['Medicines', 'Suppliers', 'Alerts'] },
  { title: 'Dispensing', routes: ['Dispense (Rx)'] },
];
const PURPLE = '#7c3aed';

export default function PharmacyTabs() {
  return (
    <PharmacyDataProvider>
      <Drawer.Navigator
        drawerContent={(props) => <Sidebar {...props} portalName="Pharmacy Portal" icons={ICONS} accent={PURPLE} sections={SECTIONS} />}
        screenOptions={{
          headerStyle: { backgroundColor: '#5b21b6' },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: '700' },
          drawerStyle: { width: 260 },
          headerLeft: () => <HeaderLeft />,
        }}
      >
        <Drawer.Screen name="Overview" component={PharmacyOverviewScreen} options={{ title: 'Pharmacy Portal' }} />
        <Drawer.Screen name="Medicines" component={MedicinesScreen} options={{ title: 'Medicines' }} />
        <Drawer.Screen name="Suppliers" component={SuppliersScreen} options={{ title: 'Suppliers' }} />
        <Drawer.Screen name="Alerts" component={AlertsScreen} options={{ title: 'Alerts' }} />
        <Drawer.Screen name="Dispense (Rx)" component={DispenseScreen} options={{ title: 'Dispense (Rx)' }} />
      </Drawer.Navigator>
    </PharmacyDataProvider>
  );
}
