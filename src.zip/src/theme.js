export const C = {
  navy: '#0f2540',
  navyMid: '#1a365d',
  blue: '#2563eb',
  blueDark: '#1d4ed8',
  blueSoft: '#eff6ff',
  slate: '#64748b',
  border: '#e2e8f0',
  bg: '#f8fafc',
  white: '#ffffff',
  text: '#0f172a',
  textMuted: '#64748b',
  green: '#16a34a',
  greenBg: '#f0fdf4',
  greenBorder: '#bbf7d0',
  amber: '#d97706',
  amberBg: '#fffbeb',
  amberBorder: '#fde68a',
  red: '#dc2626',
  redBg: '#fef2f2',
  redBorder: '#fecaca',
  purple: '#7c3aed',
  purpleBg: '#f5f3ff',
  indigo: '#6366f1',
  indigoBg: '#eef2ff',
  indigoBorder: '#c7d2fe',
  sky: '#0ea5e9',
  skyBg: '#f0f9ff',
  skyBorder: '#bae6fd',
  muted: '#94a3b8',
  faint: '#f1f5f9',
};

export const RADIUS = { sm: 8, md: 12, lg: 16, xl: 20, pill: 999 };

export const SPACE = { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 28 };

export const SHADOW = {
  card: {
    shadowColor: '#0f172a',
    shadowOpacity: 0.06,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
};
